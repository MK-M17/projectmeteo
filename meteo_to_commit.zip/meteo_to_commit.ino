#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <DNSServer.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_INA219.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <EEPROM.h>

extern "C" {
#include "user_interface.h"
}

#define SDA_PIN 4
#define SCL_PIN 5
#define ONE_WIRE_BUS 16
#define BUTTON_PIN 13
#define LED_PIN 12
#define GEIGER_PIN 14

const unsigned long SLEEP_TIME_MS = 600000;

const unsigned long CMD_CHECK_MS = 600000UL;
const unsigned long LIVE_POLL_MS = 3000UL;
const unsigned long ONDEMAND_MEASURE_MS = 0UL;

const float GEIGER_USV_PER_CPM = 0.0057;

const char* HARDCODED_BOT_TOKEN = "8734878988:AAH6I0sMjav-d65p4vPwKaCgoERxnaFub5s";

struct Config {
  char ssid[32];
  char password[32];
  char python_server[64];
  int python_port;
  char botToken[50];
  char chat_id[15];
  int send_interval_min;
  int marker;
} settings;

ESP8266WebServer server(80);
DNSServer dnsServer;
Adafruit_BMP280 bmp;
Adafruit_INA219 ina219;
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature dallasSensors(&oneWire);

bool configMode = false;
bool ledState = LOW;
bool isFirstConnect = true;
unsigned long lastLedTime = 0;
volatile bool buttonPressed = false;

volatile unsigned long geigerPulses = 0;
unsigned long geigerWindowStart = 0;

bool liveMode = false;
bool measureRequested = false;
unsigned long lastSendAt = 0;
unsigned long nextSendAt = 0;
unsigned long nextCheckAt = 0;
unsigned long nextPollAt = 0;

bool due(unsigned long t) {
  return (long)(millis() - t) >= 0;
}

void IRAM_ATTR buttonISR() {
  buttonPressed = true;
}

void IRAM_ATTR geigerISR() {
  geigerPulses++;
}

unsigned long getGeigerCountsAndReset() {
  noInterrupts();
  unsigned long counts = geigerPulses;
  geigerPulses = 0;
  interrupts();
  return counts;
}

void loadConfig() {
  EEPROM.get(0, settings);
  if (settings.marker != 12345) {
    memset(&settings, 0, sizeof(Config));
    settings.python_port = 8000;
    settings.send_interval_min = 10;
  }
}

void saveConfig() {
  settings.marker = 12345;
  EEPROM.put(0, settings);
  EEPROM.commit();
}

void handleRoot() {
  String html = "<!DOCTYPE html><html lang='uk'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'><title>Weather Config</title>";
  html += "<style>body{background:#161719;color:#d8d9da;font-family:-apple-system,BlinkMacSystemFont,sans-serif;text-align:center;padding:10px;margin:0;}";
  html += ".box{background:#1f2226;border:1px solid #2a2c30;padding:20px;max-width:340px;margin:30px auto;border-radius:6px;box-shadow:0 4px 15px rgba(0,0,0,0.4);}";
  html += "h2{color:#fff;font-size:18px;margin-bottom:20px;text-transform:uppercase;letter-spacing:1px;}";
  html += "label{display:block;text-align:left;font-size:11px;color:#7b8087;text-transform:uppercase;font-weight:600;margin:10px 0 4px 5px;}";
  html += "input{display:block;margin-bottom:15px;padding:10px;width:100%;box-sizing:border-box;background:#161719;border:1px solid #2a2c30;color:#fff;border-radius:4px;font-size:14px;}";
  html += "input:focus{border-color:#4f92ff;outline:none;}";
  html += "button{background:#4f92ff;color:#fff;border:none;padding:12px;border-radius:4px;cursor:pointer;font-weight:600;font-size:14px;width:100%;margin-top:10px;text-transform:uppercase;}";
  html += "button:hover{background:#357ae8;}</style></head><body>";
  html += "<div class='box'><h2>Налаштування станції</h2><form action='/save' method='POST'>";
  html += "<label>Назва Wi-Fi мережі</label><input type='text' name='ssid' value='" + String(settings.ssid) + "' placeholder='Назва мережі'>";
  html += "<label>Пароль Wi-Fi</label><input type='password' name='password' value='" + String(settings.password) + "' placeholder='Пароль'>";
  html += "<label>IP адреса / Домен сайту</label><input type='text' name='server' value='" + String(settings.python_server) + "' placeholder='Сайт'>";
  html += "<label>Порт сервера</label><input type='number' name='port' value='" + String(settings.python_port) + "'>";
  html += "<label>Telegram Chat ID</label><input type='text' name='chat' value='" + String(settings.chat_id) + "' placeholder='Chat ID'>";
  html += "<label>Інтервал відправки (у хвилинах)</label><input type='number' name='interval' value='" + String(settings.send_interval_min) + "' min='10' max='1440'>";
  html += "<button type='submit'>Зберегти параметри</button></form></div></body></html>";
  server.send(200, "text/html", html);
}

void handleSave() {
  char oldServer[64];
  memcpy(oldServer, settings.python_server, sizeof(oldServer));

  memset(&settings, 0, sizeof(Config));
  strncpy(settings.ssid, server.arg("ssid").c_str(), 32);
  strncpy(settings.password, server.arg("password").c_str(), 32);
  if (server.arg("server").length() > 0) {
    strncpy(settings.python_server, server.arg("server").c_str(), 63);
  } else {
    memcpy(settings.python_server, oldServer, sizeof(oldServer));
    settings.python_server[63] = '\0';
  }
  settings.python_port = server.arg("port").toInt();
  strncpy(settings.chat_id, server.arg("chat").c_str(), 15);

  int inputInterval = server.arg("interval").toInt();
  if (inputInterval < 10) inputInterval = 10;
  settings.send_interval_min = inputInterval;

  saveConfig();
  server.send(200, "text/html", "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body style='background:#161719;color:#fff;font-family:sans-serif;text-align:center;padding:50px;'><h3>Параметри збережено!<br>Метеостанція перезавантажується...</h3></body></html>");
  delay(2000);
  ESP.restart();
}

String numOrNull(float v, int digits) {
  if (isnan(v) || isinf(v)) return "null";
  return String(v, digits);
}

void sendDataToPythonServer(float dallasTemp, float bmpTemp, float pressure, float vbat, float current, float power, float cpm, float usvh) {
  WiFiClient client;
  if (client.connect(settings.python_server, settings.python_port)) {
    String url = "/api/post-data/";
    String jsonPayload = "{\"temp_dallas\":" + String(dallasTemp, 1) + ",\"temp_bmp\":" + String(bmpTemp, 1) + ",\"pressure\":" + String(pressure, 1) + ",\"voltage\":" + String(vbat, 2) + ",\"current\":" + String(current, 1) + ",\"power\":" + String(power, 1) + ",\"radiation_cpm\":" + numOrNull(cpm, 1) + ",\"radiation_usvh\":" + numOrNull(usvh, 3) + "}";
    client.print(String("POST ") + url + " HTTP/1.1\r\nHost: " + String(settings.python_server) + ":" + String(settings.python_port) + "\r\nContent-Type: application/json\r\nContent-Length: " + String(jsonPayload.length()) + "\r\nConnection: close\r\n\r\n" + jsonPayload);
    client.stop();
  }
}

void sendTelegramMessage(String text) {
  WiFiClientSecure client;
  client.setInsecure();
  if (client.connect("api.telegram.org", 443)) {
    text.replace("\n", "%0A"); text.replace(" ", "%20");
    String url = "/bot" + String(HARDCODED_BOT_TOKEN) + "/sendMessage?chat_id=" + String(settings.chat_id) + "&text=" + text;
    client.print(String("GET ") + url + " HTTP/1.1\r\nHost: api.telegram.org\r\nConnection: close\r\n\r\n");
    client.stop();
  }
}

bool wifiUp() {
  if (WiFi.status() == WL_CONNECTED) return true;
  WiFi.forceSleepWake();
  delay(1);
  WiFi.mode(WIFI_STA);
  WiFi.begin(settings.ssid, settings.password);
  int wifiTimeout = 0;
  while (WiFi.status() != WL_CONNECTED && wifiTimeout < 30) {
    if (buttonPressed) return false;
    delay(500);
    wifiTimeout++;
  }
  return WiFi.status() == WL_CONNECTED;
}

void wifiDown() {
  WiFi.disconnect();
  WiFi.mode(WIFI_OFF);
  WiFi.forceSleepBegin();
  delay(1);
}

void pollCommands() {
  if (WiFi.status() != WL_CONNECTED) return;
  WiFiClient client;
  if (!client.connect(settings.python_server, settings.python_port)) return;
  client.print(String("GET /api/station/poll/ HTTP/1.1\r\nHost: ") + String(settings.python_server) + ":" + String(settings.python_port) + "\r\nConnection: close\r\n\r\n");

  String resp = "";
  unsigned long t = millis();
  while ((client.connected() || client.available()) && millis() - t < 3000) {
    while (client.available()) resp += (char)client.read();
    delay(5);
  }
  client.stop();

  int ip = resp.indexOf("interval=");
  int lp = resp.indexOf("live=");
  int mp = resp.indexOf("measure=");
  if (ip < 0) return;

  int iv = resp.substring(ip + 9).toInt();
  if (lp >= 0) liveMode = (resp.substring(lp + 5).toInt() == 1);
  if (mp >= 0 && resp.substring(mp + 8).toInt() == 1) measureRequested = true;

  if (iv >= 10 && iv <= 1440 && iv != settings.send_interval_min) {
    settings.send_interval_min = iv;
    saveConfig();
    nextSendAt = lastSendAt + (unsigned long)iv * 60000UL;
  }
}

void readAndSendAllData(bool onDemand) {
  if (!wifiUp()) {
    if (buttonPressed) return;
    if (!liveMode) wifiDown();
    return;
  }

  unsigned long onDemandCounts = 0;
  unsigned long onDemandMs = 0;

  if (onDemand && ONDEMAND_MEASURE_MS == 0) {
    noInterrupts();
    onDemandCounts = geigerPulses;
    interrupts();
    onDemandMs = millis() - geigerWindowStart;
  } else if (onDemand) {
    noInterrupts();
    unsigned long p0 = geigerPulses;
    interrupts();
    unsigned long t0 = millis();
    while (millis() - t0 < ONDEMAND_MEASURE_MS) {
      if (buttonPressed) {
        digitalWrite(LED_PIN, LOW);
        return;
      }
      digitalWrite(LED_PIN, ((millis() - t0) / 500) % 2 ? HIGH : LOW);
      delay(50);
    }
    noInterrupts();
    unsigned long p1 = geigerPulses;
    interrupts();
    onDemandCounts = p1 - p0;
    onDemandMs = millis() - t0;

    if (!wifiUp()) {
      digitalWrite(LED_PIN, LOW);
      return;
    }
  }

  digitalWrite(LED_PIN, HIGH);

  if (isFirstConnect) {
    sendTelegramMessage("Підключено, інтервал " + String(settings.send_interval_min) + " хв");
    isFirstConnect = false;
  }

  dallasSensors.requestTemperatures();
  delay(750);
  float dallasTemp = dallasSensors.getTempCByIndex(0);
  int attempts = 0;
  while ((dallasTemp == 85.0 || dallasTemp == -127.0) && attempts < 5) {
    if (buttonPressed) { digitalWrite(LED_PIN, LOW); return; }
    delay(200); dallasSensors.requestTemperatures(); dallasTemp = dallasSensors.getTempCByIndex(0); attempts++;
  }
  float bmpTemp = bmp.readTemperature();
  float pressureMmHg = bmp.readPressure() * 0.00750062;
  float busVoltage = ina219.getBusVoltage_V();
  float shuntVoltage = ina219.getShuntVoltage_mV() / 1000.0;
  float vbat = busVoltage + shuntVoltage;
  float currentMa = ina219.getCurrent_mA();
  float powerMw = ina219.getPower_mW();

  if (isinf(currentMa) || isnan(currentMa)) currentMa = 0.0;
  if (isinf(powerMw) || isnan(powerMw)) powerMw = 0.0;
  if (isinf(vbat) || isnan(vbat) || vbat < 0.1) vbat = 0.0;

  unsigned long geigerCounts;
  unsigned long elapsedMs;
  if (onDemand) {
    geigerCounts = onDemandCounts;
    elapsedMs = onDemandMs;
  } else {
    unsigned long nowMs = millis();
    geigerCounts = getGeigerCountsAndReset();
    elapsedMs = nowMs - geigerWindowStart;
    geigerWindowStart = nowMs;
  }

  float cpm = NAN;
  float usvh = NAN;
  if (elapsedMs > 0 && (!onDemand || ONDEMAND_MEASURE_MS > 0 || elapsedMs >= 60000UL)) {
    cpm = geigerCounts / (elapsedMs / 60000.0);
    usvh = cpm * GEIGER_USV_PER_CPM;
  }

  sendDataToPythonServer(dallasTemp, bmpTemp, pressureMmHg, vbat, currentMa, powerMw, cpm, usvh);

  String batteryStatus = (currentMa > 0) ? "Зарядка " : "Розрядка ";
  String radLine = isnan(cpm) ? String("— (замало даних)") : (String(cpm, 1) + " CPM (" + String(usvh, 3) + " μSv/h)");
  String logMsg =
                  " Дані:\n"
                  " Температура : " + String(dallasTemp, 1) + " °C\n"
                  " Радіація: " + radLine + "\n"
                  " Тиск: " + String(pressureMmHg, 1) + " мм\n"
                  " Напруга АКБ: " + String(vbat, 2) + " V\n"
                  " Струм панелі: " + String(currentMa, 1) + " mA (" + batteryStatus + ")\n"
                  " Потужність: " + String(powerMw, 1) + " mW\n";
  sendTelegramMessage(logMsg);

  pollCommands();

  delay(onDemand ? 1000 : 3000);
  digitalWrite(LED_PIN, LOW);

  if (!liveMode) wifiDown();
}

void liveTick() {
  if (!due(nextPollAt)) return;
  nextPollAt = millis() + LIVE_POLL_MS;
  if (!wifiUp()) {
    nextPollAt = millis() + 10000UL;
    return;
  }
  pollCommands();
  if (measureRequested) {
    measureRequested = false;
    readAndSendAllData(true);
    nextPollAt = millis() + LIVE_POLL_MS;
  }
  if (!liveMode) wifiDown();
}

void checkTick() {
  nextCheckAt = millis() + CMD_CHECK_MS;
  if (!wifiUp()) {
    if (!buttonPressed) wifiDown();
    return;
  }
  pollCommands();
  if (!liveMode) wifiDown();
}

void startConfigPortal() {
  WiFi.forceSleepWake();
  delay(1);
  WiFi.mode(WIFI_STA);
  WiFi.begin(settings.ssid, settings.password);
  int t = 0;
  while (WiFi.status() != WL_CONNECTED && t < 15) { delay(500); t++; }
  if (WiFi.status() == WL_CONNECTED) {
    sendTelegramMessage("Перехід у режим ручного налаштування");
    delay(1000);
  }

  WiFi.disconnect();
  WiFi.mode(WIFI_AP);
  WiFi.softAP("Meteo-Station-Config");
  delay(500);
  dnsServer.start(53, "*", WiFi.softAPIP());
  server.on("/", handleRoot);
  server.on("/save", handleSave);
  server.onNotFound([]() {
    server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString() + "/", true);
    server.send(302, "text/plain", "");
  });
  server.begin();
  configMode = true;
}

void setup() {
  Serial.begin(115200);
  EEPROM.begin(512);
  loadConfig();

  pinMode(BUTTON_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  pinMode(GEIGER_PIN, INPUT);
  attachInterrupt(digitalPinToInterrupt(GEIGER_PIN), geigerISR, FALLING);
  geigerWindowStart = millis();

  Wire.begin(SDA_PIN, SCL_PIN);
  dallasSensors.begin();
  bmp.begin(0x76);
  ina219.begin();

  wifi_set_opmode(STATION_MODE);
  wifi_fpm_set_sleep_type(LIGHT_SLEEP_T);

  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), buttonISR, RISING);

  if (settings.marker != 12345 || settings.ssid[0] == '\0') {
    startConfigPortal();
  }

  nextSendAt = millis();
}

void loop() {
  if (configMode) {
    dnsServer.processNextRequest();
    server.handleClient();

    if (millis() - lastLedTime >= 500) {
      lastLedTime = millis();
      ledState = !ledState;
      digitalWrite(LED_PIN, ledState);
    }

    if (buttonPressed) {
      buttonPressed = false;
      unsigned long pressStart = millis();
      while (digitalRead(BUTTON_PIN) == HIGH) {
        if (millis() - pressStart > 2000) {
          ESP.restart();
        }
        delay(10);
      }
    }
    delay(1);
  }
  else {
    if (due(nextSendAt)) {
      buttonPressed = false;
      readAndSendAllData(false);
      lastSendAt = millis();
      nextSendAt = lastSendAt + (unsigned long)settings.send_interval_min * 60000UL;
      nextCheckAt = lastSendAt + CMD_CHECK_MS;
      nextPollAt = lastSendAt + LIVE_POLL_MS;
    } else if (liveMode) {
      liveTick();
    } else if (due(nextCheckAt)) {
      checkTick();
    }

    if (buttonPressed) {
      buttonPressed = false;
      unsigned long pressStart = millis();
      while (digitalRead(BUTTON_PIN) == HIGH) {
        if (millis() - pressStart > 2000) {
          startConfigPortal();
          break;
        }
        delay(10);
      }
    }
    delay(50);
  }
}
